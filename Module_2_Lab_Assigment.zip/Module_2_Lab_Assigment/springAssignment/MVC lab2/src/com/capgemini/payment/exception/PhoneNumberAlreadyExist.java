package com.capgemini.payment.exception;

public class PhoneNumberAlreadyExist extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PhoneNumberAlreadyExist(String string) {
		super(string);
	}

}
